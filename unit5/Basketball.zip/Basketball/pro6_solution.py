INFILE = open("player_regular_season_career.txt","r")

i=0
eff_i = []       #effectiveness

MT_i = []        #Most time

MA_i = []        #Most appearances

MS_i = []        #Most score

MR_i = []        #Most rebound

MPI_i = []       #Most penalty in

MP_i = []        #Most penalty

for line in INFILE:    
    if(i==0):
        i += 1
        continue
    i+=1
    fields = line.split('|')   
    
    firstName = fields[1]    
    lastName = fields[2]
        
    minutes= int(fields[5])     
    
    gp,pts,reb,asts,stl,blk,turnover,fga,fgm,fta,ftm =\
    int(fields[4]),int(fields[6]),int(fields[9]),int(fields[10]),int(fields[11]),int(fields[12]),\
    int(fields[13]),int(fields[15]),int(fields[16]),int(fields[17]),int(fields[18])
    
    efficiency = (pts+reb+asts+stl+blk-(fga-fgm)+fta-ftm+turnover)/float(gp)   
    
    eff_i.append([efficiency,firstName,lastName])             
    
    MT_i.append([minutes,firstName,lastName])                

    MA_i.append([gp,firstName,lastName])                     
    
    MS_i.append([pts,firstName,lastName])                    

    MR_i.append([reb,firstName,lastName])                    

    MPI_i.append([ftm,firstName,lastName])                    

    MP_i.append([fta,firstName,lastName])                    
    
print ("Data collection completed ")

eff_i.sort(reverse = True)   

MT_i.sort(reverse = True)

MA_i.sort(reverse = True)

MS_i.sort(reverse = True)

MR_i.sort(reverse = True)

MPI_i.sort(reverse = True)

MP_i.sort(reverse = True)

#top50
OUTFILE = open("top50.txt","w")
for i in range(50):
    OUTFILE.write(eff_i[i][1]+" "+eff_i[i][2]+","+str(eff_i[i][0])+"\n")
OUTFILE.close()
print ("finished")

#Output
print ("six players with the most playing time:")
for a in range(6):
     print(MT_i[a][1]+" "+MT_i[a][2]+","+str(MT_i[a][0])+"\n")   
     
print ("six players with the most appearances")
for b in range(6):
     print(MA_i[b][1]+" "+MA_i[b][2]+","+str(MA_i[b][0])+"\n")   

print ("Six players with the most scores")
for c in range(6):
    print(MS_i[c][1]+" "+MS_i[c][2]+","+str(MS_i[c][0])+"\n")
    
print ("Six players with the most rebounds")    
for d in range(6):
    print(MR_i[d][1]+" "+MR_i[d][2]+","+str(MR_i[d][0])+"\n")     

print ("Six players with the most penalty in")       
for e in range(6):
     print(MPI_i[e][1]+" "+MPI_i[e][2]+","+str(MPI_i[e][0])+"\n")   

print ("Six players with the most penalty")        
for f in range(6):
     print(MP_i[e][1]+" "+MP_i[f][2]+","+str(MP_i[f][0])+"\n")
     

print ("output finished")

