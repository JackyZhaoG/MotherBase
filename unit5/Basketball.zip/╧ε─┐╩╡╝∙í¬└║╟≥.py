INFILE = open("player_regular_season_career.txt","r")

i=0
li = []          #一个空表,计算效率

ai = []          #一个空表，计算上场时间最多的选手

bi = []          #一个空表，计算参加比赛场次最多的选手

ci = []          #一个空表，计算参加得分最多的选手

di = []          #一个空表，计算参加篮板最多的选手

ei = []          #一个空表，计算参加罚中次数最多的选手

fi = []          #一个空表，计算参加罚球次数最多的选手

for line in INFILE:    #一行一行的检索
    if(i==0):
        i += 1
        continue
    i+=1
    fields = line.split('|')   #将字符串进行切片
    
    firstName = fields[1]    
    lastName = fields[2]
        
    minutes= int(fields[5])     #将上场时间放入表内
    
    gp,pts,reb,asts,stl,blk,turnover,fga,fgm,fta,ftm =\
    int(fields[4]),int(fields[6]),int(fields[9]),int(fields[10]),int(fields[11]),int(fields[12]),\
    int(fields[13]),int(fields[15]),int(fields[16]),int(fields[17]),int(fields[18])
    
    efficiency = (pts+reb+asts+stl+blk-(fga-fgm)+fta-ftm+turnover)/float(gp)   #计算该球员的效率
    
    li.append([efficiency,firstName,lastName])             #将该球员的效率和名字关联起来
    
    ai.append([minutes,firstName,lastName])                #将该球员的上场时间和名字关联起来

    bi.append([gp,firstName,lastName])                     #将该球员的比赛场次和名字关联起来
    
    ci.append([pts,firstName,lastName])                    #将该球员的得分和名字关联起来

    di.append([reb,firstName,lastName])                    #将该球员的篮板和名字关联起来

    ei.append([ftm,firstName,lastName])                    #将该球员的罚中次数和名字关联起来

    fi.append([fta,firstName,lastName])                    #将该球员的罚球次数和名字关联起来
    
print ("数据搜集完成 ")

li.sort(reverse = True)   #按降序排序

ai.sort(reverse = True)

bi.sort(reverse = True)

ci.sort(reverse = True)

di.sort(reverse = True)

ei.sort(reverse = True)

fi.sort(reverse = True)

#以下为top50列表的创建
OUTFILE = open("top50.txt","w")
for i in range(50):
    OUTFILE.write(li[i][1]+" "+li[i][2]+","+str(li[i][0])+"\n")
OUTFILE.close()
print ("完成")

#以下为其他统计信息的输出
print ("以下为上场时间最多的六位选手")
for a in range(6):
     print(ai[a][1]+" "+ai[a][2]+","+str(ai[a][0])+"\n")   #输出上场时间最多的六位选手
     
print ("以下为比赛场次最多的六位选手")
for b in range(6):
     print(bi[b][1]+" "+bi[b][2]+","+str(bi[b][0])+"\n")   #输出比赛场次最多的六位选手

print ("以下为得分最多的六位选手")
for c in range(6):
    print(ci[c][1]+" "+ci[c][2]+","+str(ci[c][0])+"\n")    #输出得分最多的六位选手

print ("以下为篮板最多的六位选手")    
for d in range(6):
    print(di[d][1]+" "+di[d][2]+","+str(di[d][0])+"\n")    #输出篮板最多的六位选手  

print ("以下为罚中次数最多的六位选手")       
for e in range(6):
     print(ei[e][1]+" "+ei[e][2]+","+str(ei[e][0])+"\n")   #输出罚中次数最多的六位选手

print ("以下为罚球次数最多的六位选手")        
for f in range(6):
     print(fi[e][1]+" "+fi[f][2]+","+str(fi[f][0])+"\n")   #输出罚球次数最多的六位选手
     

print ("输出完毕")

